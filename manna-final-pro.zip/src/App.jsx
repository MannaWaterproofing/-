
export default function App(){
 const card={background:'#fff',padding:'24px',borderRadius:'20px',boxShadow:'0 10px 30px rgba(0,0,0,.08)'};
 return <div style={{fontFamily:'Arial,sans-serif',margin:0,color:'#0f172a',background:'#f8fafc'}}>
 <div style={{background:'#0b3a75',color:'#fff',padding:'10px 30px',display:'flex',justifyContent:'space-between',flexWrap:'wrap'}}>
 <span>📞 80009797 / 80009714</span><span>✉️ Manna.waterproofing@gmail.com</span><span>Улаанбаатар хот</span></div>
 <section style={{padding:'70px 30px',background:'linear-gradient(135deg,#0b3a75,#1e40af)',color:'#fff'}}>
 <h1 style={{fontSize:'54px',margin:'0 0 10px'}}>Manna Waterproofing</h1>
 <p style={{fontSize:'22px',maxWidth:'760px'}}>PVC мембран борлуулалт, дээврийн ус тусгаарлалтын FINAL PRO шийдэл</p>
 <div style={{marginTop:'25px'}}><button style={{padding:'14px 22px',borderRadius:'14px',border:'none'}}>Үнэ авах</button></div>
 </section>
 <section style={{padding:'40px 30px',display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))',gap:'20px'}}>
 <div style={card}><h3>PVC Мембран</h3><p>1.2мм / 1.5мм / 2.0мм өндөр чанартай материал.</p></div>
 <div style={card}><h3>Суурилуулалт</h3><p>Мэргэжлийн баг, баталгаат гүйцэтгэл.</p></div>
 <div style={card}><h3>Үнийн Санал</h3><p>Талбайн хэмжээсээр шуурхай тооцоо.</p></div>
 <div style={card}><h3>24/7 Зөвлөгөө</h3><p>Яаралтай засвар, инженерийн зөвлөгөө.</p></div>
 </section>
 <section style={{padding:'20px 30px 60px'}}>
 <h2>Яагаад биднийг сонгох вэ?</h2>
 <ul>
 <li>Чанарын баталгаа</li><li>Туршлагатай хамт олон</li><li>Өрсөлдөхүйц үнэ</li><li>Хурдан хугацаа</li>
 </ul>
 </section>
 <footer style={{background:'#0f172a',color:'#fff',padding:'30px'}}>© 2026 Manna Waterproofing</footer>
 </div>
}
